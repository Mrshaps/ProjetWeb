<?php 

?>
<!DOCTYPE html>
<html id='html'>
<head>
	<title>Mini projet BDD</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/script.js"></script>
  <meta charset="utf8_unicode_ci">
</head>
<body>
<div id="page">
  <div id="header"> 
    
  </div>

<?php  // menu ?>
